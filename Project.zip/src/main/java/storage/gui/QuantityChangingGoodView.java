package storage.gui;

import javax.swing.JPanel;

public class QuantityChangingGoodView extends JPanel {

	/**
	 * Create the panel.
	 */
	public QuantityChangingGoodView() {

	}

}
