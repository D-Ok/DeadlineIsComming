package storage.exceptions;

public class InvalidCharacteristicOfGoodsException extends Exception {
	public InvalidCharacteristicOfGoodsException() {
		super();
	}
	
	public InvalidCharacteristicOfGoodsException(String e) {
		super(e);
	}
}

